/*********************************************************************
** Program Filename: player.h
** Author: Helena Bales
** Date: 04/23/2014
** Description: struct for the player to keep track of score and num
** Input: none
** Output: none
********************************************************************/

struct player {
   
   int num;
   int score;

};
